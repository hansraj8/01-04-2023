export interface getAllCrop{
    CropId: number, 
    CropTypeId: number, 
    FarmerId: number,  
    User: any,  
    CropName: string,  
    Location: string,
    QtyAvailable: number,
    ExpectedPrice: number,
    CropType: any,
    Invoices: any
}