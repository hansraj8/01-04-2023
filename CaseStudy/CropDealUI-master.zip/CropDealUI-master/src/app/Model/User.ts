export class User{
    role ='';
    userName='';
    password = '';
    
}