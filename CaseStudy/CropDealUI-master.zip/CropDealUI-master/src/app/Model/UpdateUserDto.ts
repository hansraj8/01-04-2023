export interface UpdateUserDto{
    email: string,
    phone:number,

    line:string,
    city:  string,
    state:string,
    accountNumber:number,
    bankName: string
}