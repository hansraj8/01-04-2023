export class GetUser{
    name =''
    email=''
    phone=0
    bankname=''
    ifsc=''
    accnumber=0
    address=''
}