export class Payment{
    cropId=0
    farmerId=0
    dealerId=0
}