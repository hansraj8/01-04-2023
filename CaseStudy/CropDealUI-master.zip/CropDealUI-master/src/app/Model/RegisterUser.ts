export class RegisterUser{
    Role ='';
    Name='';
    Email='';
    Password = '';
    Phone= '';
    Line= '';
    City= '';
    State= '';
    AccountNumber= '';
    IFSC= '';
    BankName = '';
}