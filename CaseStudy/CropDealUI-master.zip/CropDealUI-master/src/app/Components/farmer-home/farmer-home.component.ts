import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farmer-home',
  templateUrl: './farmer-home.component.html',
  styleUrls: ['./farmer-home.component.css']
})
export class FarmerHomeComponent implements OnInit {

  constructor() { }
  
  ngOnInit(): void {
   
  }

}
