export class UserPageDto{
       
       
        Email = "";
        Phone? : number;

        Line = "";
        City = "";
        State ="";
      
        AccountNumber? : number;
        IFSCCode = "";
        BankName = "";
}